package com.robloxmod.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Classic Sword ala Roblox: klik kanan = lunge (loncat nyerang ke depan). */
public class ClassicSwordItem extends SwordItem {

    public static final ToolMaterial CLASSIC = new ToolMaterial() {
        @Override public int getDurability() { return 700; }
        @Override public float getMiningSpeedMultiplier() { return 6.0f; }
        @Override public float getAttackDamage() { return 2.0f; }   // total damage = 1 + 3 + 2 = 6
        @Override public int getMiningLevel() { return 2; }
        @Override public int getEnchantability() { return 15; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(net.minecraft.item.Items.IRON_INGOT); }
    };

    public ClassicSwordItem(Item.Settings settings) {
        super(CLASSIC, 3, -2.4f, settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        Vec3d look = player.getRotationVec(1.0f);
        player.setVelocity(player.getVelocity().add(look.x * 1.3, 0.35, look.z * 1.3));
        player.velocityModified = true;
        player.getItemCooldownManager().set(this, 40);
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 1.0f);
        return TypedActionResult.success(stack, world.isClient());
    }
}
