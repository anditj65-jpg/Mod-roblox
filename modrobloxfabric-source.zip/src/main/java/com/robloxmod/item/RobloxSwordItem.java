package com.robloxmod.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

/** Pedang Roblox dengan efek saat memukul. */
public class RobloxSwordItem extends SwordItem {
    public enum Effect { NONE, FIRE, SLOW, POISON, WITHER }

    private final Effect effect;

    public RobloxSwordItem(ToolMaterial material, int damage, float speed, Effect effect, Item.Settings settings) {
        super(material, damage, speed, settings);
        this.effect = effect;
    }

    public static ToolMaterial material(int durability, float attackDamage, int enchantability) {
        return new ToolMaterial() {
            @Override public int getDurability() { return durability; }
            @Override public float getMiningSpeedMultiplier() { return 6.0f; }
            @Override public float getAttackDamage() { return attackDamage; }
            @Override public int getMiningLevel() { return 2; }
            @Override public int getEnchantability() { return enchantability; }
            @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.IRON_INGOT); }
        };
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        switch (effect) {
            case FIRE -> target.setOnFireFor(5);
            case SLOW -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1), attacker);
            case POISON -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1), attacker);
            case WITHER -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80, 1), attacker);
            default -> { }
        }
        return super.postHit(stack, target, attacker);
    }
}
