package com.robloxmod.item;

import com.robloxmod.RobloxMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Klik kanan: pindah ke Roblox World. Klik kanan lagi di sana: balik ke Overworld. */
public class PortalOrbItem extends Item {
    public PortalOrbItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient || !(player instanceof ServerPlayerEntity sp) || sp.getServer() == null) {
            return TypedActionResult.success(stack, world.isClient());
        }

        boolean inRoblox = world.getRegistryKey() == RobloxMod.ROBLOX_WORLD;
        ServerWorld target = sp.getServer().getWorld(inRoblox ? World.OVERWORLD : RobloxMod.ROBLOX_WORLD);
        if (target == null) {
            return TypedActionResult.fail(stack);
        }

        BlockPos dest;
        if (inRoblox) {
            BlockPos base = target.getSpawnPos();
            dest = topAt(target, base.getX(), base.getZ());
        } else {
            dest = findSafe(target, 0, 0);
        }

        sp.teleport(target, dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5, sp.getYaw(), sp.getPitch());
        sp.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 200, 0));
        sp.getItemCooldownManager().set(this, 100);
        return TypedActionResult.success(stack, false);
    }

    /** Muat chunk dulu (penting!), baru baca tinggi tanah. */
    private static BlockPos topAt(ServerWorld w, int x, int z) {
        w.getChunk(x >> 4, z >> 4);
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
        return new BlockPos(x, y, z);
    }

    /** Cari titik berpijakan (tanah/pasir, di atas permukaan laut, bukan pohon/air). */
    private static BlockPos findSafe(ServerWorld w, int cx, int cz) {
        for (int r = 0; r <= 12; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    int x = cx + dx * 8;
                    int z = cz + dz * 8;
                    BlockPos p = topAt(w, x, z);
                    BlockState below = w.getBlockState(p.down());
                    boolean ground = below.isIn(BlockTags.DIRT) || below.isOf(Blocks.SAND);
                    if (p.getY() > w.getSeaLevel() && ground
                            && w.getBlockState(p).isAir() && w.getBlockState(p.up()).isAir()) {
                        return p;
                    }
                }
            }
        }
        // cadangan: bikin platform kecil di udara
        BlockPos p = new BlockPos(cx, 120, cz);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                w.setBlockState(p.add(dx, -1, dz), Blocks.STONE.getDefaultState());
            }
        }
        return p;
    }
}
