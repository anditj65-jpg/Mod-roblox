package com.robloxmod.item;

import com.robloxmod.RobloxMod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Klik kanan: pindah ke Roblox World. Klik kanan lagi di sana: balik ke Overworld. */
public class PortalOrbItem extends Item {
    public PortalOrbItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient || !(player instanceof ServerPlayerEntity sp)) {
            return TypedActionResult.success(stack, world.isClient());
        }

        boolean inRoblox = world.getRegistryKey() == RobloxMod.ROBLOX_WORLD;
        ServerWorld target = sp.getServer().getWorld(inRoblox ? World.OVERWORLD : RobloxMod.ROBLOX_WORLD);
        if (target == null) {
            return TypedActionResult.fail(stack);
        }

        BlockPos base = inRoblox ? target.getSpawnPos() : new BlockPos(0, 0, 0);
        int y = target.getTopY(Heightmap.Type.MOTION_BLOCKING, base.getX(), base.getZ());
        sp.teleport(target, base.getX() + 0.5, y, base.getZ() + 0.5, sp.getYaw(), sp.getPitch());
        sp.getItemCooldownManager().set(this, 100);
        return TypedActionResult.success(stack, false);
    }
}
