package com.robloxmod.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/** Gear Roblox: Speed Coil / Gravity Coil. Aktif kalau dipegang di tangan. */
public class CoilItem extends Item {
    private final boolean gravity;

    public CoilItem(boolean gravity, Settings settings) {
        super(settings);
        this.gravity = gravity;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isClient && selected && entity instanceof LivingEntity living) {
            if (gravity) {
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 10, 4, false, false, false));
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 10, 0, false, false, false));
            } else {
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 10, 3, false, false, false));
            }
        }
    }
}
