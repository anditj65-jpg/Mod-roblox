package com.robloxmod;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Blok pohon khas Roblox (batang + daun), supaya dunia Roblox tidak pakai pohon Minecraft. */
public class ModBlocks {
    public static final Block ROBLOX_LOG = register("roblox_log",
            new PillarBlock(FabricBlockSettings.copyOf(Blocks.OAK_LOG)));
    public static final Block ROBLOX_LEAVES = register("roblox_leaves",
            new LeavesBlock(FabricBlockSettings.copyOf(Blocks.OAK_LEAVES)));
    public static final Block ROBLOX_LEAVES_ORANGE = register("roblox_leaves_orange",
            new LeavesBlock(FabricBlockSettings.copyOf(Blocks.OAK_LEAVES)));

    private static Block register(String name, Block block) {
        Identifier id = new Identifier(RobloxMod.MOD_ID, name);
        Registry.register(Registries.ITEM, id, new BlockItem(block, new FabricItemSettings()));
        return Registry.register(Registries.BLOCK, id, block);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(e -> {
            e.add(ROBLOX_LOG); e.add(ROBLOX_LEAVES); e.add(ROBLOX_LEAVES_ORANGE);
        });
    }
}
