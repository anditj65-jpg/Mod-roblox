package com.robloxmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class RobloxMod implements ModInitializer {
    public static final String MOD_ID = "robloxmod";

    public static final RegistryKey<World> ROBLOX_WORLD =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(MOD_ID, "roblox_world"));

    @Override
    public void onInitialize() {
        ModEntities.register();   // entity dulu, baru item (spawn egg butuh entity)
        ModItems.register();
    }
}
