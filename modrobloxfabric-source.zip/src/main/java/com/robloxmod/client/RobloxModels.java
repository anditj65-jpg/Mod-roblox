package com.robloxmod.client;

import net.minecraft.client.model.*;

/** DIBUAT OTOMATIS: model 3D karakter Roblox (proporsi blocky R6). */
public class RobloxModels {
    private static final int TEX = 128;

    public static TexturedModelData noob() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(28, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(58, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(78, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(98, 0).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bacon() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 2, 7, new Dilation(0.4f))
                .uv(56, 0).cuboid(-3.5f, -5f, 1.5f, 7, 5, 2, new Dilation(0.4f))
                .uv(74, 0).cuboid(-3.5f, -5f, -1.5f, 1, 3, 3, new Dilation(0.4f))
                .uv(82, 0).cuboid(2.5f, -5f, -1.5f, 1, 3, 3, new Dilation(0.4f))
                .uv(90, 0).cuboid(-3.5f, -5f, -3.5f, 7, 1, 1, new Dilation(0.4f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 14).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(30, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(50, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(70, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(90, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData guest() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 3, 7, new Dilation(0.45f))
                .uv(56, 0).cuboid(-3.5f, -4.5f, -6.5f, 7, 1, 3, new Dilation(0.1f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(76, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(106, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(0, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(20, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(40, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData robloxian() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 2, 7, new Dilation(0.45f))
                .uv(56, 0).cuboid(-3.5f, -5f, 1.5f, 7, 9, 2, new Dilation(0.45f))
                .uv(74, 0).cuboid(-3.5f, -5f, -1.5f, 1, 6, 3, new Dilation(0.45f))
                .uv(82, 0).cuboid(2.5f, -5f, -1.5f, 1, 6, 3, new Dilation(0.45f))
                .uv(90, 0).cuboid(-3.5f, -5f, -3.5f, 7, 1, 1, new Dilation(0.45f))
                .uv(106, 0).cuboid(-1.5f, -8.5f, -1f, 3, 3, 3, new Dilation(0.3f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 14).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(30, 14).cuboid(-6f, 7f, -3.5f, 12, 6, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(68, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(88, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(108, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 29).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData builder() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 3, 7, new Dilation(0.6f))
                .uv(56, 0).cuboid(-1f, -8f, -3.5f, 2, 1, 7, new Dilation(0.6f))
                .uv(74, 0).cuboid(-3.5f, -4.5f, -6.5f, 7, 1, 3, new Dilation(0.2f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(94, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(0, 15).cuboid(-5f, 7.5f, -2.5f, 10, 2, 5, new Dilation(0.4f))
                .uv(30, 15).cuboid(3f, 6.5f, -3.5f, 3, 3, 1, new Dilation(0.2f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(38, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(58, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(78, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(98, 15).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(20, 30).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

}