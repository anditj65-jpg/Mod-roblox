package com.robloxmod.client;

import net.minecraft.client.model.*;

/** DIBUAT OTOMATIS: model 3D karakter & hewan Roblox. */
public class RobloxModels {
    private static final int TEX = 128;

    public static TexturedModelData noob() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(28, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(58, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(78, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(98, 0).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bacon() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 2, 7, new Dilation(0.4f))
                .uv(56, 0).cuboid(-3.5f, -5f, 1.5f, 7, 5, 2, new Dilation(0.4f))
                .uv(74, 0).cuboid(-3.5f, -5f, -1.5f, 1, 3, 3, new Dilation(0.4f))
                .uv(82, 0).cuboid(2.5f, -5f, -1.5f, 1, 3, 3, new Dilation(0.4f))
                .uv(90, 0).cuboid(-3.5f, -5f, -3.5f, 7, 1, 1, new Dilation(0.4f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 14).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(30, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(50, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(70, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(90, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData guest() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 3, 7, new Dilation(0.45f))
                .uv(56, 0).cuboid(-3.5f, -4.5f, -6.5f, 7, 1, 3, new Dilation(0.1f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(76, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(106, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(0, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(20, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(40, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData robloxian() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 2, 7, new Dilation(0.45f))
                .uv(56, 0).cuboid(-3.5f, -5f, 1.5f, 7, 9, 2, new Dilation(0.45f))
                .uv(74, 0).cuboid(-3.5f, -5f, -1.5f, 1, 6, 3, new Dilation(0.45f))
                .uv(82, 0).cuboid(2.5f, -5f, -1.5f, 1, 6, 3, new Dilation(0.45f))
                .uv(90, 0).cuboid(-3.5f, -5f, -3.5f, 7, 1, 1, new Dilation(0.45f))
                .uv(106, 0).cuboid(-1.5f, -8.5f, -1f, 3, 3, 3, new Dilation(0.3f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 14).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(30, 14).cuboid(-6f, 7f, -3.5f, 12, 6, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(68, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(88, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(108, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 29).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData builder() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 3, 7, new Dilation(0.6f))
                .uv(56, 0).cuboid(-1f, -8f, -3.5f, 2, 1, 7, new Dilation(0.6f))
                .uv(74, 0).cuboid(-3.5f, -4.5f, -6.5f, 7, 1, 3, new Dilation(0.2f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(94, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(0, 15).cuboid(-5f, 7.5f, -2.5f, 10, 2, 5, new Dilation(0.4f))
                .uv(30, 15).cuboid(3f, 6.5f, -3.5f, 3, 3, 1, new Dilation(0.2f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(38, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(58, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(78, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(98, 15).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(20, 30).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData roblox_zombie() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(28, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(58, 0).cuboid(-5.5f, 8f, -3f, 11, 3, 6)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(92, 0).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(0, 15).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(20, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(40, 15).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData roblox_skeleton() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(28, 0).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(58, 0).cuboid(-1.5f, -2f, -1.5f, 3, 10, 3)
                , ModelTransform.pivot(-6.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(70, 0).cuboid(-1.5f, -2f, -1.5f, 3, 10, 3)
                , ModelTransform.pivot(6.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(82, 0).cuboid(-1.5f, 0f, -1.5f, 3, 10, 3)
                , ModelTransform.pivot(-2f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(94, 0).cuboid(-1.5f, 0f, -1.5f, 3, 10, 3)
                , ModelTransform.pivot(2f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData builderman() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -7f, -3.5f, 7, 7, 7)
                .uv(28, 0).cuboid(-3.5f, -7f, -3.5f, 7, 3, 7, new Dilation(0.6f))
                .uv(56, 0).cuboid(-1f, -8f, -3.5f, 2, 1, 7, new Dilation(0.6f))
                .uv(74, 0).cuboid(-3.5f, -4.5f, -6.5f, 7, 1, 3, new Dilation(0.2f))
                .uv(94, 0).cuboid(-3.5f, -5.5f, -3.5f, 7, 1, 7, new Dilation(0.62f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 14).cuboid(-5f, 0f, -2.5f, 10, 10, 5)
                .uv(30, 14).cuboid(-5f, 7.5f, -2.5f, 10, 2, 5, new Dilation(0.4f))
                .uv(60, 14).cuboid(3f, 6.5f, -3.5f, 3, 3, 1, new Dilation(0.2f))
                , ModelTransform.pivot(0f, 4f, 0f));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(68, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(-7.5f, 6f, 0f));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(88, 14).cuboid(-2.5f, -2f, -2.5f, 5, 10, 5)
                , ModelTransform.pivot(7.5f, 6f, 0f));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(108, 14).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(0, 29).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(-2.5f, 14f, 0f));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(20, 29).cuboid(-2.5f, 0f, -2.5f, 5, 10, 5)
                .uv(40, 29).cuboid(-2.5f, 8f, -2.5f, 5, 2, 5, new Dilation(0.3f))
                , ModelTransform.pivot(2.5f, 14f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bloxy_pig() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -3.5f, -6f, 7, 7, 6)
                .uv(26, 0).cuboid(-2f, 0f, -7f, 4, 3, 1)
                .uv(36, 0).cuboid(-3.5f, -5f, -2f, 2, 2, 1)
                .uv(42, 0).cuboid(1.5f, -5f, -2f, 2, 2, 1)
                , ModelTransform.pivot(0f, 12f, -6f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(48, 0).cuboid(-4f, 10f, -6f, 8, 8, 12)
                .uv(88, 0).cuboid(-0.5f, 11f, 6f, 1, 1, 2)
                , ModelTransform.pivot(0f, 0f, 0f));
        root.addChild("leg_fr", ModelPartBuilder.create()
                .uv(94, 0).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-2.5f, 18f, -4f));
        root.addChild("leg_fl", ModelPartBuilder.create()
                .uv(106, 0).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(2.5f, 18f, -4f));
        root.addChild("leg_br", ModelPartBuilder.create()
                .uv(0, 20).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-2.5f, 18f, 4f));
        root.addChild("leg_bl", ModelPartBuilder.create()
                .uv(12, 20).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(2.5f, 18f, 4f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bloxy_sheep() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3f, -3.5f, -5f, 6, 6, 5)
                .uv(22, 0).cuboid(-3.5f, -5.5f, -3f, 7, 2, 6, new Dilation(0.2f))
                .uv(48, 0).cuboid(-4.5f, -3f, -3f, 1, 2, 2)
                .uv(54, 0).cuboid(3.5f, -3f, -3f, 1, 2, 2)
                , ModelTransform.pivot(0f, 11f, -6f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(60, 0).cuboid(-5f, 8f, -6f, 10, 10, 12, new Dilation(0.3f))
                , ModelTransform.pivot(0f, 0f, 0f));
        root.addChild("leg_fr", ModelPartBuilder.create()
                .uv(104, 0).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-3f, 18f, -4f));
        root.addChild("leg_fl", ModelPartBuilder.create()
                .uv(116, 0).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(3f, 18f, -4f));
        root.addChild("leg_br", ModelPartBuilder.create()
                .uv(0, 22).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-3f, 18f, 4f));
        root.addChild("leg_bl", ModelPartBuilder.create()
                .uv(12, 22).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(3f, 18f, 4f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bloxy_cow() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4f, -4f, -6f, 8, 7, 6)
                .uv(28, 0).cuboid(-5f, -6f, -3f, 1, 2, 1)
                .uv(32, 0).cuboid(4f, -6f, -3f, 1, 2, 1)
                .uv(36, 0).cuboid(1f, -4.5f, -2f, 3, 2, 3)
                , ModelTransform.pivot(0f, 10f, -7f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(48, 0).cuboid(-5f, 8f, -7f, 10, 10, 14)
                .uv(96, 0).cuboid(-2f, 18f, 2f, 4, 2, 4)
                , ModelTransform.pivot(0f, 0f, 0f));
        root.addChild("leg_fr", ModelPartBuilder.create()
                .uv(112, 0).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-3f, 18f, -5f));
        root.addChild("leg_fl", ModelPartBuilder.create()
                .uv(0, 24).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(3f, 18f, -5f));
        root.addChild("leg_br", ModelPartBuilder.create()
                .uv(12, 24).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(-3f, 18f, 5f));
        root.addChild("leg_bl", ModelPartBuilder.create()
                .uv(24, 24).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3)
                , ModelTransform.pivot(3f, 18f, 5f));
        return TexturedModelData.of(md, TEX, TEX);
    }

    public static TexturedModelData bloxy_chicken() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-2f, -5f, -2f, 4, 5, 4)
                .uv(16, 0).cuboid(-1f, -3f, -4f, 2, 1, 2)
                .uv(24, 0).cuboid(-0.5f, -7f, -1f, 1, 2, 3)
                .uv(32, 0).cuboid(-0.5f, -2f, -3.5f, 1, 2, 1)
                , ModelTransform.pivot(0f, 15f, -3f));
        root.addChild("body", ModelPartBuilder.create()
                .uv(36, 0).cuboid(-2.5f, 15f, -3f, 5, 5, 6)
                .uv(58, 0).cuboid(-3.5f, 15.5f, -2f, 1, 3, 4)
                .uv(68, 0).cuboid(2.5f, 15.5f, -2f, 1, 3, 4)
                .uv(78, 0).cuboid(-1f, 14f, 3f, 2, 4, 2)
                , ModelTransform.pivot(0f, 0f, 0f));
        root.addChild("leg_fr", ModelPartBuilder.create()
                .uv(86, 0).cuboid(-1f, 0f, -1f, 2, 4, 2)
                , ModelTransform.pivot(-1.5f, 20f, 0f));
        root.addChild("leg_fl", ModelPartBuilder.create()
                .uv(94, 0).cuboid(-1f, 0f, -1f, 2, 4, 2)
                , ModelTransform.pivot(1.5f, 20f, 0f));
        return TexturedModelData.of(md, TEX, TEX);
    }

}