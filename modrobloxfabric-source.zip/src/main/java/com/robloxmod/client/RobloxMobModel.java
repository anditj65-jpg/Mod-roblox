package com.robloxmod.client;

import com.robloxmod.entity.RobloxMobEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;

/** Tangan tetap turun di samping badan (bukan pose zombie). Saat menyerang, tangan mengayun. */
public class RobloxMobModel extends BipedEntityModel<RobloxMobEntity> {
    public RobloxMobModel(ModelPart root) {
        super(root);
        this.rightArmPose = BipedEntityModel.ArmPose.ITEM;
    }
}
