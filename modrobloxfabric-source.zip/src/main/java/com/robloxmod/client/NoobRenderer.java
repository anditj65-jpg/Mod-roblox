package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import com.robloxmod.entity.NoobEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class NoobRenderer extends BipedEntityRenderer<NoobEntity, BipedEntityModel<NoobEntity>> {
    private static final Identifier TEXTURE = new Identifier(RobloxMod.MOD_ID, "textures/entity/noob.png");

    public NoobRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new NoobModel(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public Identifier getTexture(NoobEntity entity) {
        return TEXTURE;
    }
}
