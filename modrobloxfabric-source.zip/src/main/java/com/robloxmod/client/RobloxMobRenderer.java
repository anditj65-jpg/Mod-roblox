package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import com.robloxmod.entity.RobloxMobEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class RobloxMobRenderer extends BipedEntityRenderer<RobloxMobEntity, BipedEntityModel<RobloxMobEntity>> {
    private final Identifier texture;
    private final float size;

    public RobloxMobRenderer(EntityRendererFactory.Context ctx, EntityModelLayer layer, String name, float size) {
        super(ctx, new RobloxMobModel(ctx.getPart(layer)), 0.5f * size);
        this.texture = new Identifier(RobloxMod.MOD_ID, "textures/entity/" + name + ".png");
        this.size = size;
    }

    @Override
    protected void scale(RobloxMobEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(size, size, size);
    }

    @Override
    public Identifier getTexture(RobloxMobEntity entity) {
        return texture;
    }
}
