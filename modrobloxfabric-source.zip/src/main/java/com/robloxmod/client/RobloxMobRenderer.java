package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import com.robloxmod.entity.RobloxMobEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class RobloxMobRenderer extends BipedEntityRenderer<RobloxMobEntity, BipedEntityModel<RobloxMobEntity>> {
    private final Identifier texture;

    public RobloxMobRenderer(EntityRendererFactory.Context ctx, String name) {
        super(ctx, new RobloxMobModel(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.texture = new Identifier(RobloxMod.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public Identifier getTexture(RobloxMobEntity entity) {
        return texture;
    }
}
