package com.robloxmod.client;

import com.robloxmod.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RobloxModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        RobloxModelLayers.register();
        EntityRendererRegistry.register(ModEntities.NOOB, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.NOOB, "noob", 1.0f));
        EntityRendererRegistry.register(ModEntities.BACON, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.BACON, "bacon", 1.0f));
        EntityRendererRegistry.register(ModEntities.GUEST, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.GUEST, "guest", 1.0f));
        EntityRendererRegistry.register(ModEntities.ROBLOXIAN, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.ROBLOXIAN, "robloxian", 1.0f));
        EntityRendererRegistry.register(ModEntities.BUILDER, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.BUILDER, "builder", 1.15f));
        EntityRendererRegistry.register(ModEntities.ROBLOX_ZOMBIE, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.ROBLOX_ZOMBIE, "roblox_zombie", 1.0f));
        EntityRendererRegistry.register(ModEntities.ROBLOX_SKELETON, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.ROBLOX_SKELETON, "roblox_skeleton", 1.0f));
        EntityRendererRegistry.register(ModEntities.BUILDERMAN, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.BUILDERMAN, "builderman", 1.15f));
        EntityRendererRegistry.register(ModEntities.BLOXY_CHICKEN, ctx -> new BloxyAnimalRenderer(ctx, RobloxModelLayers.BLOXY_CHICKEN, "bloxy_chicken", 0.7f));
        EntityRendererRegistry.register(ModEntities.BLOXY_SHEEP, ctx -> new BloxyAnimalRenderer(ctx, RobloxModelLayers.BLOXY_SHEEP, "bloxy_sheep", 1.0f));
        EntityRendererRegistry.register(ModEntities.BLOXY_PIG, ctx -> new BloxyAnimalRenderer(ctx, RobloxModelLayers.BLOXY_PIG, "bloxy_pig", 1.0f));
        EntityRendererRegistry.register(ModEntities.BLOXY_COW, ctx -> new BloxyAnimalRenderer(ctx, RobloxModelLayers.BLOXY_COW, "bloxy_cow", 1.0f));
    }
}