package com.robloxmod.client;

import com.robloxmod.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RobloxModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.NOOB, ctx -> new RobloxMobRenderer(ctx, "noob"));
        EntityRendererRegistry.register(ModEntities.BACON, ctx -> new RobloxMobRenderer(ctx, "bacon"));
        EntityRendererRegistry.register(ModEntities.GUEST, ctx -> new RobloxMobRenderer(ctx, "guest"));
        EntityRendererRegistry.register(ModEntities.ROBLOXIAN, ctx -> new RobloxMobRenderer(ctx, "robloxian"));
        EntityRendererRegistry.register(ModEntities.BUILDER, ctx -> new RobloxMobRenderer(ctx, "builder"));
    }
}
