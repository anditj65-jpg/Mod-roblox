package com.robloxmod.client;

import com.robloxmod.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class RobloxModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        RobloxModelLayers.register();
        EntityRendererRegistry.register(ModEntities.NOOB, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.NOOB, "noob", 1.0f));
        EntityRendererRegistry.register(ModEntities.BACON, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.BACON, "bacon", 1.0f));
        EntityRendererRegistry.register(ModEntities.GUEST, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.GUEST, "guest", 1.0f));
        EntityRendererRegistry.register(ModEntities.ROBLOXIAN, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.ROBLOXIAN, "robloxian", 1.0f));
        EntityRendererRegistry.register(ModEntities.BUILDER, ctx -> new RobloxMobRenderer(ctx, RobloxModelLayers.BUILDER, "builder", 1.15f));
    }
}
