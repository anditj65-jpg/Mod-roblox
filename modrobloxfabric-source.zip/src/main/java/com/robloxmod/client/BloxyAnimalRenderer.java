package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import com.robloxmod.entity.BloxyAnimalEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class BloxyAnimalRenderer extends MobEntityRenderer<BloxyAnimalEntity, BloxyAnimalModel> {
    private final Identifier texture;
    private final float size;

    public BloxyAnimalRenderer(EntityRendererFactory.Context ctx, EntityModelLayer layer, String name, float size) {
        super(ctx, new BloxyAnimalModel(ctx.getPart(layer)), 0.45f * size);
        this.texture = new Identifier(RobloxMod.MOD_ID, "textures/entity/" + name + ".png");
        this.size = size;
    }

    @Override
    protected void scale(BloxyAnimalEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(size, size, size);
    }

    @Override
    public Identifier getTexture(BloxyAnimalEntity entity) {
        return texture;
    }
}
