package com.robloxmod.client;

import com.robloxmod.entity.NoobEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.CrossbowPosing;

public class NoobModel extends BipedEntityModel<NoobEntity> {
    public NoobModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setAngles(NoobEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
        CrossbowPosing.meleeAttack(this.leftArm, this.rightArm, entity.isAttacking(),
                this.handSwingProgress, animationProgress);
    }
}
