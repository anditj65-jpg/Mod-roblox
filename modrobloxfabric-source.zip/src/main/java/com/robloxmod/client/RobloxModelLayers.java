package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class RobloxModelLayers {
    public static final EntityModelLayer NOOB = layer("noob");
    public static final EntityModelLayer BACON = layer("bacon");
    public static final EntityModelLayer GUEST = layer("guest");
    public static final EntityModelLayer ROBLOXIAN = layer("robloxian");
    public static final EntityModelLayer BUILDER = layer("builder");
    public static final EntityModelLayer ROBLOX_ZOMBIE = layer("roblox_zombie");
    public static final EntityModelLayer ROBLOX_SKELETON = layer("roblox_skeleton");
    public static final EntityModelLayer BUILDERMAN = layer("builderman");
    public static final EntityModelLayer BLOXY_CHICKEN = layer("bloxy_chicken");
    public static final EntityModelLayer BLOXY_SHEEP = layer("bloxy_sheep");
    public static final EntityModelLayer BLOXY_PIG = layer("bloxy_pig");
    public static final EntityModelLayer BLOXY_COW = layer("bloxy_cow");

    private static EntityModelLayer layer(String name) {
        return new EntityModelLayer(new Identifier(RobloxMod.MOD_ID, name), "main");
    }

    public static void register() {
        EntityModelLayerRegistry.registerModelLayer(NOOB, RobloxModels::noob);
        EntityModelLayerRegistry.registerModelLayer(BACON, RobloxModels::bacon);
        EntityModelLayerRegistry.registerModelLayer(GUEST, RobloxModels::guest);
        EntityModelLayerRegistry.registerModelLayer(ROBLOXIAN, RobloxModels::robloxian);
        EntityModelLayerRegistry.registerModelLayer(BUILDER, RobloxModels::builder);
        EntityModelLayerRegistry.registerModelLayer(ROBLOX_ZOMBIE, RobloxModels::roblox_zombie);
        EntityModelLayerRegistry.registerModelLayer(ROBLOX_SKELETON, RobloxModels::roblox_skeleton);
        EntityModelLayerRegistry.registerModelLayer(BUILDERMAN, RobloxModels::builderman);
        EntityModelLayerRegistry.registerModelLayer(BLOXY_CHICKEN, RobloxModels::bloxy_chicken);
        EntityModelLayerRegistry.registerModelLayer(BLOXY_SHEEP, RobloxModels::bloxy_sheep);
        EntityModelLayerRegistry.registerModelLayer(BLOXY_PIG, RobloxModels::bloxy_pig);
        EntityModelLayerRegistry.registerModelLayer(BLOXY_COW, RobloxModels::bloxy_cow);
    }
}