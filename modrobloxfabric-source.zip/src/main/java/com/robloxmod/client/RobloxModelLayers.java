package com.robloxmod.client;

import com.robloxmod.RobloxMod;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class RobloxModelLayers {
    public static final EntityModelLayer NOOB = layer("noob");
    public static final EntityModelLayer BACON = layer("bacon");
    public static final EntityModelLayer GUEST = layer("guest");
    public static final EntityModelLayer ROBLOXIAN = layer("robloxian");
    public static final EntityModelLayer BUILDER = layer("builder");

    private static EntityModelLayer layer(String name) {
        return new EntityModelLayer(new Identifier(RobloxMod.MOD_ID, name), "main");
    }

    public static void register() {
        EntityModelLayerRegistry.registerModelLayer(NOOB, RobloxModels::noob);
        EntityModelLayerRegistry.registerModelLayer(BACON, RobloxModels::bacon);
        EntityModelLayerRegistry.registerModelLayer(GUEST, RobloxModels::guest);
        EntityModelLayerRegistry.registerModelLayer(ROBLOXIAN, RobloxModels::robloxian);
        EntityModelLayerRegistry.registerModelLayer(BUILDER, RobloxModels::builder);
    }
}
