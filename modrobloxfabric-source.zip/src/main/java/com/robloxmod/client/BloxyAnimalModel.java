package com.robloxmod.client;

import com.robloxmod.entity.BloxyAnimalEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class BloxyAnimalModel extends EntityModel<BloxyAnimalEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart legFr, legFl, legBr, legBl;

    public BloxyAnimalModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.legFr = opt(root, "leg_fr");
        this.legFl = opt(root, "leg_fl");
        this.legBr = opt(root, "leg_br");
        this.legBl = opt(root, "leg_bl");
    }

    private static ModelPart opt(ModelPart root, String name) {
        try {
            return root.getChild(name);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void setAngles(BloxyAnimalEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        this.head.yaw = headYaw * 0.017453292f;
        this.head.pitch = headPitch * 0.017453292f;
        float a = MathHelper.cos(limbAngle * 0.6662f) * 1.4f * limbDistance;
        float b = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 1.4f * limbDistance;
        if (legFr != null) legFr.pitch = a;
        if (legFl != null) legFl.pitch = b;
        if (legBr != null) legBr.pitch = b;
        if (legBl != null) legBl.pitch = a;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        this.root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
