package com.robloxmod;

import com.robloxmod.item.ClassicSwordItem;
import com.robloxmod.item.PortalOrbItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item CLASSIC_SWORD = register("classic_sword",
            new ClassicSwordItem(new FabricItemSettings().maxCount(1)));

    public static final Item PORTAL_ORB = register("portal_orb",
            new PortalOrbItem(new FabricItemSettings().maxCount(1)));

    public static final Item NOOB_SPAWN_EGG = register("noob_spawn_egg",
            new SpawnEggItem(ModEntities.NOOB, 0xF5CD2F, 0x0D6EEF, new FabricItemSettings()));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(RobloxMod.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(CLASSIC_SWORD));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(PORTAL_ORB));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> e.add(NOOB_SPAWN_EGG));
    }
}
