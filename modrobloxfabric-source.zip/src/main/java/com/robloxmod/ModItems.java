package com.robloxmod;

import com.robloxmod.item.*;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    // ---- Pedang ----
    public static final Item CLASSIC_SWORD = register("classic_sword",
            new ClassicSwordItem(new FabricItemSettings().maxCount(1)));
    public static final Item LINKED_SWORD = register("linked_sword",
            new RobloxSwordItem(RobloxSwordItem.material(700, 2.0f, 14), 3, -2.2f,
                    RobloxSwordItem.Effect.NONE, new FabricItemSettings().maxCount(1)));
    public static final Item FIREBRAND = register("firebrand",
            new RobloxSwordItem(RobloxSwordItem.material(600, 2.5f, 15), 3, -2.4f,
                    RobloxSwordItem.Effect.FIRE, new FabricItemSettings().maxCount(1)));
    public static final Item ICE_DAGGER = register("ice_dagger",
            new RobloxSwordItem(RobloxSwordItem.material(500, 2.0f, 15), 1, -1.6f,
                    RobloxSwordItem.Effect.SLOW, new FabricItemSettings().maxCount(1)));
    public static final Item VENOMSHANK = register("venomshank",
            new RobloxSwordItem(RobloxSwordItem.material(550, 2.0f, 15), 2, -2.0f,
                    RobloxSwordItem.Effect.POISON, new FabricItemSettings().maxCount(1)));
    public static final Item DARKHEART = register("darkheart",
            new RobloxSwordItem(RobloxSwordItem.material(900, 3.0f, 18), 4, -2.6f,
                    RobloxSwordItem.Effect.WITHER, new FabricItemSettings().maxCount(1)));
    public static final Item BAN_HAMMER = register("ban_hammer",
            new RobloxSwordItem(RobloxSwordItem.material(400, 3.0f, 10), 7, -3.3f,
                    RobloxSwordItem.Effect.SLOW, new FabricItemSettings().maxCount(1)));

    // ---- Gear ----
    public static final Item SPEED_COIL = register("speed_coil",
            new CoilItem(false, new FabricItemSettings().maxCount(1)));
    public static final Item GRAVITY_COIL = register("gravity_coil",
            new CoilItem(true, new FabricItemSettings().maxCount(1)));

    // ---- Lain-lain ----
    public static final Item BLOXY_COLA = register("bloxy_cola",
            new BloxyColaItem(new FabricItemSettings().food(new FoodComponent.Builder()
                    .hunger(4).saturationModifier(0.4f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 1), 1.0f)
                    .build())));
    public static final Item ROBUX = register("robux", new Item(new FabricItemSettings()));
    public static final Item PORTAL_ORB = register("portal_orb",
            new PortalOrbItem(new FabricItemSettings().maxCount(1)));

    // ---- Spawn egg ----
    public static final Item NOOB_SPAWN_EGG = egg("noob_spawn_egg", ModEntities.NOOB, 0xF5CD2F, 0x0D6EEF);
    public static final Item BACON_SPAWN_EGG = egg("bacon_spawn_egg", ModEntities.BACON, 0x613F1E, 0x5B9ADC);
    public static final Item GUEST_SPAWN_EGG = egg("guest_spawn_egg", ModEntities.GUEST, 0x222222, 0xE29B40);
    public static final Item ROBLOXIAN_SPAWN_EGG = egg("robloxian_spawn_egg", ModEntities.ROBLOXIAN, 0xD660AA, 0x8246AA);
    public static final Item BUILDER_SPAWN_EGG = egg("builder_spawn_egg", ModEntities.BUILDER, 0xFFD200, 0xE26428);

    private static Item egg(String name, EntityType<? extends net.minecraft.entity.mob.MobEntity> type, int c1, int c2) {
        return register(name, new SpawnEggItem(type, c1, c2, new FabricItemSettings()));
    }

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(RobloxMod.MOD_ID, name), item);
    }

    /** Senjata bawaan tiap karakter Roblox. */
    public static Item weaponFor(EntityType<?> type) {
        if (type == ModEntities.BACON) return LINKED_SWORD;
        if (type == ModEntities.GUEST) return ICE_DAGGER;
        if (type == ModEntities.ROBLOXIAN) return FIREBRAND;
        if (type == ModEntities.BUILDER) return BAN_HAMMER;
        return CLASSIC_SWORD;
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            e.add(CLASSIC_SWORD); e.add(LINKED_SWORD); e.add(FIREBRAND); e.add(ICE_DAGGER);
            e.add(VENOMSHANK); e.add(DARKHEART); e.add(BAN_HAMMER);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(PORTAL_ORB); e.add(SPEED_COIL); e.add(GRAVITY_COIL);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> e.add(BLOXY_COLA));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> e.add(ROBUX));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> {
            e.add(NOOB_SPAWN_EGG); e.add(BACON_SPAWN_EGG); e.add(GUEST_SPAWN_EGG);
            e.add(ROBLOXIAN_SPAWN_EGG); e.add(BUILDER_SPAWN_EGG);
        });
    }
}
