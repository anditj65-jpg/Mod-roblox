package com.robloxmod.entity;

import com.robloxmod.ModEntities;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

/** Hewan versi Roblox (ayam, domba, babi, sapi). Pasif, kabur kalau diserang. */
public class BloxyAnimalEntity extends PathAwareEntity {

    public BloxyAnimalEntity(EntityType<? extends BloxyAnimalEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttrs(double health, double speed) {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, health)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, speed);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new EscapeDangerGoal(this, 1.4));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    public static boolean canAnimalSpawn(EntityType<BloxyAnimalEntity> type, ServerWorldAccess world,
                                         SpawnReason reason, BlockPos pos, Random random) {
        return world.getBlockState(pos.down()).isOf(Blocks.GRASS_BLOCK) && world.getBaseLightLevel(pos, 0) > 8;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        EntityType<?> t = this.getType();
        if (t == ModEntities.BLOXY_CHICKEN) return SoundEvents.ENTITY_CHICKEN_AMBIENT;
        if (t == ModEntities.BLOXY_SHEEP) return SoundEvents.ENTITY_SHEEP_AMBIENT;
        if (t == ModEntities.BLOXY_PIG) return SoundEvents.ENTITY_PIG_AMBIENT;
        return SoundEvents.ENTITY_COW_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        EntityType<?> t = this.getType();
        if (t == ModEntities.BLOXY_CHICKEN) return SoundEvents.ENTITY_CHICKEN_HURT;
        if (t == ModEntities.BLOXY_SHEEP) return SoundEvents.ENTITY_SHEEP_HURT;
        if (t == ModEntities.BLOXY_PIG) return SoundEvents.ENTITY_PIG_HURT;
        return SoundEvents.ENTITY_COW_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        EntityType<?> t = this.getType();
        if (t == ModEntities.BLOXY_CHICKEN) return SoundEvents.ENTITY_CHICKEN_DEATH;
        if (t == ModEntities.BLOXY_SHEEP) return SoundEvents.ENTITY_SHEEP_DEATH;
        if (t == ModEntities.BLOXY_PIG) return SoundEvents.ENTITY_PIG_DEATH;
        return SoundEvents.ENTITY_COW_DEATH;
    }
}
