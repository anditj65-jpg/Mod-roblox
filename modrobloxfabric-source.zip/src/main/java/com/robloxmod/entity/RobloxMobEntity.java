package com.robloxmod.entity;

import com.robloxmod.ModEntities;
import com.robloxmod.ModItems;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

/** Karakter Roblox. Senjata tergantung jenisnya. Builderman = NPC netral (baru marah kalau diserang). */
public class RobloxMobEntity extends HostileEntity {

    public RobloxMobEntity(EntityType<? extends RobloxMobEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttrs(double health, double speed, double damage) {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, health)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, speed)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, damage)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    public boolean isNeutralNpc() {
        return this.getType() == ModEntities.BUILDERMAN;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.15, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        if (!isNeutralNpc()) {
            this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        }
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.weaponFor(this.getType())));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.05f);
    }

    /** HostileEntity tidak memanggil initEquipment sendiri, jadi dipanggil manual. */
    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason,
                                 EntityData entityData, NbtCompound entityNbt) {
        EntityData data = super.initialize(world, difficulty, spawnReason, entityData, entityNbt);
        this.initEquipment(world.getRandom(), difficulty);
        return data;
    }

    /** Cadangan: mob dari struktur/command (tanpa initialize) tetap dikasih senjata. */
    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient && this.age == 1) {
            if (this.getMainHandStack().isEmpty()) {
                this.initEquipment(this.random, this.getWorld().getLocalDifficulty(this.getBlockPos()));
            }
            if (isNeutralNpc()) {
                this.setPersistent();
            }
        }
    }

    public static boolean canRobloxSpawn(EntityType<RobloxMobEntity> type, ServerWorldAccess world,
                                         SpawnReason reason, BlockPos pos, Random random) {
        return world.getDifficulty() != Difficulty.PEACEFUL
                && MobEntity.canMobSpawn(type, world, reason, pos, random);
    }

    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_PLAYER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PLAYER_DEATH; }
}
