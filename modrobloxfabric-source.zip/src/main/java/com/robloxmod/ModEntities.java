package com.robloxmod;

import com.robloxmod.entity.RobloxMobEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

import java.util.List;

public class ModEntities {
    public static final EntityType<RobloxMobEntity> NOOB = mob("noob", 0.6f, 1.8f);
    public static final EntityType<RobloxMobEntity> BACON = mob("bacon", 0.6f, 1.8f);
    public static final EntityType<RobloxMobEntity> GUEST = mob("guest", 0.6f, 1.8f);
    public static final EntityType<RobloxMobEntity> ROBLOXIAN = mob("robloxian", 0.6f, 1.8f);
    public static final EntityType<RobloxMobEntity> BUILDER = mob("builder", 0.75f, 2.1f);

    private static EntityType<RobloxMobEntity> mob(String name, float w, float h) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(RobloxMod.MOD_ID, name),
                FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, RobloxMobEntity::new)
                        .dimensions(EntityDimensions.fixed(w, h))
                        .trackRangeChunks(8)
                        .build());
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(NOOB, RobloxMobEntity.createAttrs(30, 0.29, 4));
        FabricDefaultAttributeRegistry.register(BACON, RobloxMobEntity.createAttrs(26, 0.31, 4));
        FabricDefaultAttributeRegistry.register(GUEST, RobloxMobEntity.createAttrs(24, 0.33, 3.5));
        FabricDefaultAttributeRegistry.register(ROBLOXIAN, RobloxMobEntity.createAttrs(28, 0.30, 4));
        FabricDefaultAttributeRegistry.register(BUILDER, RobloxMobEntity.createAttrs(60, 0.25, 7));

        for (EntityType<RobloxMobEntity> t : List.of(NOOB, BACON, GUEST, ROBLOXIAN, BUILDER)) {
            SpawnRestriction.register(t, SpawnRestriction.Location.ON_GROUND,
                    Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, RobloxMobEntity::canRobloxSpawn);
        }
    }
}
