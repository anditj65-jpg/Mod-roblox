package com.robloxmod;

import com.robloxmod.entity.NoobEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class ModEntities {
    public static final EntityType<NoobEntity> NOOB = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(RobloxMod.MOD_ID, "noob"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, NoobEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackRangeChunks(8)
                    .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(NOOB, NoobEntity.createNoobAttributes());
        SpawnRestriction.register(NOOB, SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, NoobEntity::canNoobSpawn);
    }
}
