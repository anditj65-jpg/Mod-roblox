package com.robloxmod;

import com.robloxmod.entity.BloxyAnimalEntity;
import com.robloxmod.entity.RobloxMobEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

import java.util.List;

public class ModEntities {
    // --- Karakter Roblox ---
    public static final EntityType<RobloxMobEntity> NOOB = mob("noob", 0.7f, 1.8f);
    public static final EntityType<RobloxMobEntity> BACON = mob("bacon", 0.7f, 1.8f);
    public static final EntityType<RobloxMobEntity> GUEST = mob("guest", 0.7f, 1.8f);
    public static final EntityType<RobloxMobEntity> ROBLOXIAN = mob("robloxian", 0.7f, 1.8f);
    public static final EntityType<RobloxMobEntity> BUILDER = mob("builder", 0.85f, 2.1f);
    public static final EntityType<RobloxMobEntity> ROBLOX_ZOMBIE = mob("roblox_zombie", 0.7f, 1.8f);
    public static final EntityType<RobloxMobEntity> ROBLOX_SKELETON = mob("roblox_skeleton", 0.6f, 1.8f);
    public static final EntityType<RobloxMobEntity> BUILDERMAN = mob("builderman", 0.85f, 2.1f);

    // --- Hewan Roblox ---
    public static final EntityType<BloxyAnimalEntity> BLOXY_CHICKEN = animal("bloxy_chicken", 0.45f, 0.75f);
    public static final EntityType<BloxyAnimalEntity> BLOXY_SHEEP = animal("bloxy_sheep", 0.9f, 1.05f);
    public static final EntityType<BloxyAnimalEntity> BLOXY_PIG = animal("bloxy_pig", 0.85f, 0.95f);
    public static final EntityType<BloxyAnimalEntity> BLOXY_COW = animal("bloxy_cow", 0.95f, 1.1f);

    private static EntityType<RobloxMobEntity> mob(String name, float w, float h) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(RobloxMod.MOD_ID, name),
                FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, RobloxMobEntity::new)
                        .dimensions(EntityDimensions.fixed(w, h))
                        .trackRangeChunks(8)
                        .build());
    }

    private static EntityType<BloxyAnimalEntity> animal(String name, float w, float h) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(RobloxMod.MOD_ID, name),
                FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, BloxyAnimalEntity::new)
                        .dimensions(EntityDimensions.fixed(w, h))
                        .trackRangeChunks(8)
                        .build());
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(NOOB, RobloxMobEntity.createAttrs(30, 0.29, 4));
        FabricDefaultAttributeRegistry.register(BACON, RobloxMobEntity.createAttrs(26, 0.31, 4));
        FabricDefaultAttributeRegistry.register(GUEST, RobloxMobEntity.createAttrs(24, 0.33, 3.5));
        FabricDefaultAttributeRegistry.register(ROBLOXIAN, RobloxMobEntity.createAttrs(28, 0.30, 4));
        FabricDefaultAttributeRegistry.register(BUILDER, RobloxMobEntity.createAttrs(60, 0.25, 7));
        FabricDefaultAttributeRegistry.register(ROBLOX_ZOMBIE, RobloxMobEntity.createAttrs(24, 0.23, 3.5));
        FabricDefaultAttributeRegistry.register(ROBLOX_SKELETON, RobloxMobEntity.createAttrs(20, 0.27, 3));
        FabricDefaultAttributeRegistry.register(BUILDERMAN, RobloxMobEntity.createAttrs(120, 0.28, 9));

        FabricDefaultAttributeRegistry.register(BLOXY_CHICKEN, BloxyAnimalEntity.createAttrs(4, 0.25));
        FabricDefaultAttributeRegistry.register(BLOXY_SHEEP, BloxyAnimalEntity.createAttrs(8, 0.23));
        FabricDefaultAttributeRegistry.register(BLOXY_PIG, BloxyAnimalEntity.createAttrs(10, 0.25));
        FabricDefaultAttributeRegistry.register(BLOXY_COW, BloxyAnimalEntity.createAttrs(10, 0.20));

        for (EntityType<RobloxMobEntity> t : List.of(NOOB, BACON, GUEST, ROBLOXIAN, BUILDER, ROBLOX_ZOMBIE, ROBLOX_SKELETON)) {
            SpawnRestriction.register(t, SpawnRestriction.Location.ON_GROUND,
                    Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, RobloxMobEntity::canRobloxSpawn);
        }
        for (EntityType<BloxyAnimalEntity> t : List.of(BLOXY_CHICKEN, BLOXY_SHEEP, BLOXY_PIG, BLOXY_COW)) {
            SpawnRestriction.register(t, SpawnRestriction.Location.ON_GROUND,
                    Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, BloxyAnimalEntity::canAnimalSpawn);
        }
    }
}
